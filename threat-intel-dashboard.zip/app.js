// Sample threat data
const sampleThreats = [
  {
    id: 'threat_1',
    indicator: '203.0.113.1',
    type: 'IP',
    threat_level: 'Critical',
    category: 'Phishing',
    confidence_score: 98,
    first_seen: '2025-08-15',
    last_seen: '2025-10-25',
    source: 'Multiple Sources',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_2',
    indicator: '185.220.101.1',
    type: 'IP',
    threat_level: 'Medium',
    category: 'Botnet C2',
    confidence_score: 75,
    first_seen: '2025-09-20',
    last_seen: '2025-10-25',
    source: 'VirusTotal',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_3',
    indicator: '23.129.64.1',
    type: 'IP',
    threat_level: 'Medium',
    category: 'Vulnerability Scan',
    confidence_score: 68,
    first_seen: '2025-10-01',
    last_seen: '2025-10-25',
    source: 'AbuseIPDB',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_4',
    indicator: '91.203.4.100',
    type: 'IP',
    threat_level: 'High',
    category: 'Malware Distribution',
    confidence_score: 89,
    first_seen: '2025-07-28',
    last_seen: '2025-10-25',
    source: 'Multiple Sources',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_5',
    indicator: '45.142.120.10',
    type: 'IP',
    threat_level: 'Critical',
    category: 'DDoS',
    confidence_score: 95,
    first_seen: '2025-08-05',
    last_seen: '2025-10-25',
    source: 'AbuseIPDB',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_6',
    indicator: '192.0.2.1',
    type: 'IP',
    threat_level: 'Low',
    category: 'Spam',
    confidence_score: 62,
    first_seen: '2025-10-10',
    last_seen: '2025-10-25',
    source: 'VirusTotal',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_7',
    indicator: '198.51.100.1',
    type: 'IP',
    threat_level: 'High',
    category: 'Web Attack',
    confidence_score: 87,
    first_seen: '2025-08-22',
    last_seen: '2025-10-25',
    source: 'Multiple Sources',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_8',
    indicator: '95.214.27.200',
    type: 'IP',
    threat_level: 'Medium',
    category: 'Brute Force',
    confidence_score: 71,
    first_seen: '2025-09-15',
    last_seen: '2025-10-25',
    source: 'AbuseIPDB',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_9',
    indicator: '185.220.102.240',
    type: 'IP',
    threat_level: 'Critical',
    category: 'Malware Distribution',
    confidence_score: 97,
    first_seen: '2025-07-30',
    last_seen: '2025-10-25',
    source: 'VirusTotal',
    description: 'Malicious activity detected from IP address',
    tags: []
  },
  {
    id: 'threat_10',
    indicator: '203.0.113.1',
    type: 'IP',
    threat_level: 'Low',
    category: 'Vulnerability Scan',
    confidence_score: 65,
    first_seen: '2025-10-12',
    last_seen: '2025-10-25',
    source: 'Multiple Sources',
    description: 'Malicious activity detected from IP address',
    tags: []
  }
];

// Application State
let threats = [...sampleThreats];
let currentView = 'dashboard';
let currentLookupResult = null;
let selectedTags = [];
let charts = {};

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
  initializeApp();
});

function initializeApp() {
  setupNavigation();
  setupDashboard();
  setupLookup();
  setupAnalytics();
  setupExport();
  setupModal();
  renderDashboard();
}

// Navigation
function setupNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      const view = link.getAttribute('data-view');
      switchView(view);
    });
  });
}

function switchView(view) {
  // Update navigation
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('data-view') === view) {
      link.classList.add('active');
    }
  });

  // Update views
  document.querySelectorAll('.view').forEach(v => {
    v.classList.remove('active');
  });
  document.getElementById(`${view}-view`).classList.add('active');

  currentView = view;

  // Render view content
  if (view === 'dashboard') {
    renderDashboard();
  } else if (view === 'analytics') {
    renderAnalytics();
  }
}

// Dashboard
function setupDashboard() {
  // Search functionality
  const searchInput = document.getElementById('threat-search');
  searchInput.addEventListener('input', (e) => {
    filterThreatsTable(e.target.value);
  });

  // Table sorting
  const headers = document.querySelectorAll('.threats-table th[data-sort]');
  headers.forEach(header => {
    header.addEventListener('click', () => {
      const sortBy = header.getAttribute('data-sort');
      sortThreatsTable(sortBy);
    });
  });

  // Summary card filtering
  const summaryCards = document.querySelectorAll('.summary-card');
  summaryCards.forEach(card => {
    card.addEventListener('click', () => {
      const level = card.classList.contains('critical') ? 'Critical' :
                    card.classList.contains('high') ? 'High' :
                    card.classList.contains('medium') ? 'Medium' : 'Low';
      filterThreatsTable('', level);
    });
  });
}

function renderDashboard() {
  updateSummaryCards();
  renderThreatsTable();
  renderCharts();
}

function updateSummaryCards() {
  const counts = threats.reduce((acc, threat) => {
    acc[threat.threat_level] = (acc[threat.threat_level] || 0) + 1;
    return acc;
  }, {});

  document.getElementById('critical-count').textContent = counts.Critical || 0;
  document.getElementById('high-count').textContent = counts.High || 0;
  document.getElementById('medium-count').textContent = counts.Medium || 0;
  document.getElementById('low-count').textContent = counts.Low || 0;
}

function renderThreatsTable(filteredThreats = null) {
  const tbody = document.getElementById('threats-table-body');
  const threatsToRender = filteredThreats || threats;

  tbody.innerHTML = threatsToRender.map(threat => `
    <tr>
      <td><code>${threat.indicator}</code></td>
      <td>${threat.type}</td>
      <td><span class="threat-badge ${threat.threat_level.toLowerCase()}">${threat.threat_level}</span></td>
      <td>${threat.category}</td>
      <td>${threat.confidence_score}%</td>
      <td>${threat.last_seen}</td>
      <td>${threat.source}</td>
      <td><button class="btn btn-view" onclick="viewThreatDetails('${threat.id}')">View</button></td>
    </tr>
  `).join('');
}

function filterThreatsTable(searchTerm, level = null) {
  let filtered = threats;

  if (searchTerm) {
    const term = searchTerm.toLowerCase();
    filtered = filtered.filter(threat => 
      threat.indicator.toLowerCase().includes(term) ||
      threat.category.toLowerCase().includes(term) ||
      threat.source.toLowerCase().includes(term)
    );
  }

  if (level) {
    filtered = filtered.filter(threat => threat.threat_level === level);
  }

  renderThreatsTable(filtered);
}

function sortThreatsTable(sortBy) {
  threats.sort((a, b) => {
    if (sortBy === 'confidence_score') {
      return b[sortBy] - a[sortBy];
    }
    return String(a[sortBy]).localeCompare(String(b[sortBy]));
  });
  renderThreatsTable();
}

function viewThreatDetails(threatId) {
  const threat = threats.find(t => t.id === threatId);
  if (threat) {
    currentLookupResult = threat;
    switchView('lookup');
    displayLookupResults(threat);
  }
}

function renderCharts() {
  renderCategoryChart();
  renderSourceChart();
  renderTrendChart();
}

function renderCategoryChart() {
  const ctx = document.getElementById('category-chart');
  if (!ctx) return;

  const categoryData = threats.reduce((acc, threat) => {
    acc[threat.category] = (acc[threat.category] || 0) + 1;
    return acc;
  }, {});

  if (charts.categoryChart) {
    charts.categoryChart.destroy();
  }

  charts.categoryChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: Object.keys(categoryData),
      datasets: [{
        data: Object.values(categoryData),
        backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#e1e4e8' }
        }
      }
    }
  });
}

function renderSourceChart() {
  const ctx = document.getElementById('source-chart');
  if (!ctx) return;

  const sourceData = threats.reduce((acc, threat) => {
    acc[threat.source] = (acc[threat.source] || 0) + 1;
    return acc;
  }, {});

  if (charts.sourceChart) {
    charts.sourceChart.destroy();
  }

  charts.sourceChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: Object.keys(sourceData),
      datasets: [{
        label: 'Threats',
        data: Object.values(sourceData),
        backgroundColor: '#00d4ff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: '#e1e4e8' },
          grid: { color: '#3d4258' }
        },
        x: {
          ticks: { color: '#e1e4e8' },
          grid: { color: '#3d4258' }
        }
      }
    }
  });
}

function renderTrendChart() {
  const ctx = document.getElementById('trend-chart');
  if (!ctx) return;

  // Generate last 30 days data
  const days = [];
  const data = [];
  for (let i = 29; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    data.push(Math.floor(Math.random() * 10) + 5);
  }

  if (charts.trendChart) {
    charts.trendChart.destroy();
  }

  charts.trendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: days,
      datasets: [{
        label: 'Threats Detected',
        data: data,
        borderColor: '#00d4ff',
        backgroundColor: 'rgba(0, 212, 255, 0.1)',
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: '#e1e4e8' }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: '#e1e4e8' },
          grid: { color: '#3d4258' }
        },
        x: {
          ticks: { color: '#e1e4e8', maxRotation: 45 },
          grid: { color: '#3d4258' }
        }
      }
    }
  });
}

// Threat Lookup
function setupLookup() {
  const lookupBtn = document.getElementById('lookup-btn');
  const lookupInput = document.getElementById('lookup-input');

  lookupBtn.addEventListener('click', performLookup);
  lookupInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      performLookup();
    }
  });

  // Tag threat button
  document.getElementById('tag-threat-btn').addEventListener('click', () => {
    openTagModal();
  });

  // Export report button
  document.getElementById('export-report-btn').addEventListener('click', () => {
    exportSingleThreat();
  });
}

function performLookup() {
  const input = document.getElementById('lookup-input').value.trim();
  const lookupType = document.querySelector('input[name="lookup-type"]:checked').value;
  const errorMsg = document.getElementById('lookup-error');

  // Validation
  if (!input) {
    showError('Please enter an IP address or domain');
    return;
  }

  if (lookupType === 'ip' && !validateIP(input)) {
    showError('Invalid IP address format');
    return;
  }

  if (lookupType === 'domain' && !validateDomain(input)) {
    showError('Invalid domain format');
    return;
  }

  errorMsg.classList.remove('show');

  // Show loading
  document.getElementById('lookup-results').style.display = 'none';
  document.getElementById('lookup-loading').style.display = 'block';

  // Simulate API call
  setTimeout(() => {
    const result = generateLookupResult(input, lookupType);
    displayLookupResults(result);
    document.getElementById('lookup-loading').style.display = 'none';
    document.getElementById('lookup-results').style.display = 'block';
  }, 1500);
}

function validateIP(ip) {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (!ipRegex.test(ip)) return false;
  const parts = ip.split('.');
  return parts.every(part => parseInt(part) >= 0 && parseInt(part) <= 255);
}

function validateDomain(domain) {
  const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?\.[a-zA-Z]{2,}$/;
  return domainRegex.test(domain);
}

function showError(message) {
  const errorMsg = document.getElementById('lookup-error');
  errorMsg.textContent = message;
  errorMsg.classList.add('show');
}

function generateLookupResult(indicator, type) {
  const threatLevels = ['Critical', 'High', 'Medium', 'Low'];
  const categories = ['Malware Distribution', 'Phishing', 'Botnet C2', 'Brute Force', 'DDoS', 'Spam', 'Vulnerability Scan', 'Web Attack'];
  const countries = ['United States', 'Russia', 'China', 'Germany', 'United Kingdom', 'France', 'Netherlands', 'Ukraine'];
  const cities = ['New York', 'Moscow', 'Beijing', 'Berlin', 'London', 'Paris', 'Amsterdam', 'Kyiv'];
  const isps = ['Digital Ocean', 'Amazon AWS', 'Cloudflare', 'OVH', 'Hetzner', 'Linode', 'Vultr', 'Google Cloud'];

  const threatLevel = threatLevels[Math.floor(Math.random() * threatLevels.length)];
  const riskScore = Math.floor(Math.random() * 40) + 60;
  const confidence = Math.floor(Math.random() * 30) + 70;

  return {
    id: 'lookup_' + Date.now(),
    indicator: indicator,
    type: type.toUpperCase(),
    threat_level: threatLevel,
    risk_score: riskScore,
    confidence_score: confidence,
    category: categories[Math.floor(Math.random() * categories.length)],
    detections: [
      { source: 'VirusTotal', status: Math.random() > 0.3 ? 'Malicious' : 'Clean', verdict: 'Detected by 45/70 engines' },
      { source: 'AbuseIPDB', status: Math.random() > 0.3 ? 'Malicious' : 'Clean', verdict: 'Confidence of Abuse: 87%' },
      { source: 'Shodan', status: Math.random() > 0.5 ? 'Malicious' : 'Clean', verdict: 'Open ports: 22, 80, 443' },
      { source: 'Censys', status: 'Clean', verdict: 'No malicious activity' }
    ],
    enrichment: {
      country: countries[Math.floor(Math.random() * countries.length)],
      city: cities[Math.floor(Math.random() * cities.length)],
      isp: isps[Math.floor(Math.random() * isps.length)],
      first_seen: '2025-08-15',
      last_seen: '2025-10-25',
      categories: [categories[Math.floor(Math.random() * categories.length)]]
    },
    tags: []
  };
}

function displayLookupResults(result) {
  currentLookupResult = result;

  // Indicator
  document.getElementById('threat-indicator').textContent = result.indicator;

  // Threat level
  const threatLevelEl = document.getElementById('result-threat-level');
  threatLevelEl.textContent = result.threat_level;
  threatLevelEl.className = `threat-level-badge threat-badge ${result.threat_level.toLowerCase()}`;

  // Risk score
  document.getElementById('result-risk-score').textContent = result.risk_score || result.confidence_score;

  // Confidence
  document.getElementById('result-confidence').textContent = result.confidence_score + '%';

  // Detection summary
  if (result.detections) {
    const detectionBody = document.getElementById('detection-table-body');
    detectionBody.innerHTML = result.detections.map(d => `
      <tr>
        <td>${d.source}</td>
        <td><span class="detection-status ${d.status.toLowerCase()}">${d.status}</span></td>
        <td>${d.verdict}</td>
      </tr>
    `).join('');
  }

  // Enrichment data
  if (result.enrichment) {
    document.getElementById('enrich-country').textContent = result.enrichment.country;
    document.getElementById('enrich-city').textContent = result.enrichment.city;
    document.getElementById('enrich-isp').textContent = result.enrichment.isp;
    document.getElementById('enrich-first-seen').textContent = result.enrichment.first_seen || result.first_seen;
    document.getElementById('enrich-last-seen').textContent = result.enrichment.last_seen || result.last_seen;
    document.getElementById('enrich-categories').textContent = result.enrichment.categories ? result.enrichment.categories.join(', ') : result.category;
  } else {
    document.getElementById('enrich-country').textContent = 'N/A';
    document.getElementById('enrich-city').textContent = 'N/A';
    document.getElementById('enrich-isp').textContent = 'N/A';
    document.getElementById('enrich-first-seen').textContent = result.first_seen || 'N/A';
    document.getElementById('enrich-last-seen').textContent = result.last_seen || 'N/A';
    document.getElementById('enrich-categories').textContent = result.category || 'N/A';
  }
}

function exportSingleThreat() {
  if (!currentLookupResult) return;

  const data = JSON.stringify(currentLookupResult, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `threat_report_${currentLookupResult.indicator}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('Report exported successfully!');
}

// Analytics
function setupAnalytics() {
  const timeButtons = document.querySelectorAll('.time-btn');
  timeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      timeButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderAnalytics();
    });
  });
}

function renderAnalytics() {
  updateAnalyticsMetrics();
  renderTopIPs();
  renderGeoDistribution();
  renderAnalyticsCharts();
}

function updateAnalyticsMetrics() {
  document.getElementById('metric-total').textContent = threats.length;

  // Most active category
  const categoryCount = threats.reduce((acc, threat) => {
    acc[threat.category] = (acc[threat.category] || 0) + 1;
    return acc;
  }, {});
  const mostActive = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0];
  document.getElementById('metric-category').textContent = mostActive ? mostActive[0] : 'N/A';

  // Geographic spread (simulated)
  document.getElementById('metric-geo').textContent = '12 Countries';

  // Detection sources
  const sources = new Set(threats.map(t => t.source));
  document.getElementById('metric-sources').textContent = sources.size;
}

function renderTopIPs() {
  const topList = document.getElementById('top-ips-list');
  const topThreats = threats
    .filter(t => t.threat_level === 'Critical' || t.threat_level === 'High')
    .sort((a, b) => b.confidence_score - a.confidence_score)
    .slice(0, 10);

  topList.innerHTML = topThreats.map((threat, index) => `
    <div class="list-item">
      <span class="list-item-name">${index + 1}. ${threat.indicator}</span>
      <span class="list-item-value">${threat.confidence_score}%</span>
    </div>
  `).join('');
}

function renderGeoDistribution() {
  const geoList = document.getElementById('geo-distribution-list');
  const countries = [
    { name: 'United States', count: 34 },
    { name: 'Russia', count: 28 },
    { name: 'China', count: 22 },
    { name: 'Germany', count: 18 },
    { name: 'United Kingdom', count: 15 },
    { name: 'Netherlands', count: 12 },
    { name: 'France', count: 10 },
    { name: 'Ukraine', count: 8 }
  ];

  geoList.innerHTML = countries.map(country => `
    <div class="list-item">
      <span class="list-item-name">${country.name}</span>
      <span class="list-item-value">${country.count}</span>
    </div>
  `).join('');
}

function renderAnalyticsCharts() {
  renderAnalyticsLevelChart();
  renderAnalyticsCategoryTrend();
}

function renderAnalyticsLevelChart() {
  const ctx = document.getElementById('analytics-level-chart');
  if (!ctx) return;

  const levelData = threats.reduce((acc, threat) => {
    acc[threat.threat_level] = (acc[threat.threat_level] || 0) + 1;
    return acc;
  }, {});

  if (charts.analyticsLevelChart) {
    charts.analyticsLevelChart.destroy();
  }

  charts.analyticsLevelChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: Object.keys(levelData),
      datasets: [{
        data: Object.values(levelData),
        backgroundColor: ['#ff4444', '#ff9944', '#ffdd44', '#44ff44']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: { color: '#e1e4e8' }
        }
      }
    }
  });
}

function renderAnalyticsCategoryTrend() {
  const ctx = document.getElementById('analytics-category-trend');
  if (!ctx) return;

  const categories = [...new Set(threats.map(t => t.category))];
  const days = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];

  const datasets = categories.slice(0, 5).map((category, index) => {
    const colors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'];
    return {
      label: category,
      data: days.map(() => Math.floor(Math.random() * 10) + 2),
      borderColor: colors[index],
      backgroundColor: colors[index] + '40',
      tension: 0.4
    };
  });

  if (charts.analyticsCategoryTrend) {
    charts.analyticsCategoryTrend.destroy();
  }

  charts.analyticsCategoryTrend = new Chart(ctx, {
    type: 'line',
    data: {
      labels: days,
      datasets: datasets
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: { color: '#e1e4e8' }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { color: '#e1e4e8' },
          grid: { color: '#3d4258' }
        },
        x: {
          ticks: { color: '#e1e4e8' },
          grid: { color: '#3d4258' }
        }
      }
    }
  });
}

// Export
function setupExport() {
  // Set default dates
  const today = new Date().toISOString().split('T')[0];
  const monthAgo = new Date();
  monthAgo.setMonth(monthAgo.getMonth() - 1);
  const monthAgoStr = monthAgo.toISOString().split('T')[0];

  document.getElementById('export-date-from').value = monthAgoStr;
  document.getElementById('export-date-to').value = today;

  // Generate export button
  document.getElementById('generate-export-btn').addEventListener('click', generateExport);

  // Download export button
  document.getElementById('download-export-btn').addEventListener('click', downloadExport);
}

let exportData = null;

function generateExport() {
  const format = document.getElementById('export-format').value;
  const dateFrom = document.getElementById('export-date-from').value;
  const dateTo = document.getElementById('export-date-to').value;
  const includeOptions = Array.from(document.querySelectorAll('input[name="export-data"]:checked')).map(cb => cb.value);

  // Filter threats by date range
  const filtered = threats.filter(threat => {
    const lastSeen = new Date(threat.last_seen);
    return lastSeen >= new Date(dateFrom) && lastSeen <= new Date(dateTo);
  });

  if (format === 'json') {
    exportData = {
      type: 'application/json',
      content: JSON.stringify(filtered, null, 2),
      filename: `threat_export_${dateFrom}_${dateTo}.json`
    };
  } else if (format === 'csv') {
    const headers = ['Indicator', 'Type', 'Threat Level', 'Category', 'Confidence', 'First Seen', 'Last Seen', 'Source'];
    const rows = filtered.map(t => [
      t.indicator,
      t.type,
      t.threat_level,
      t.category,
      t.confidence_score,
      t.first_seen,
      t.last_seen,
      t.source
    ]);
    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    exportData = {
      type: 'text/csv',
      content: csv,
      filename: `threat_export_${dateFrom}_${dateTo}.csv`
    };
  } else if (format === 'pdf') {
    exportData = {
      type: 'text/plain',
      content: 'PDF Report Generated\n\nThreat Intelligence Report\n' + filtered.map(t => `${t.indicator} - ${t.threat_level}`).join('\n'),
      filename: `threat_report_${dateFrom}_${dateTo}.txt`
    };
  }

  // Show success message
  document.getElementById('export-info').textContent = `${filtered.length} threats exported in ${format.toUpperCase()} format`;
  document.getElementById('export-result').style.display = 'block';
  showToast('Export generated successfully!');
}

function downloadExport() {
  if (!exportData) return;

  const blob = new Blob([exportData.content], { type: exportData.type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = exportData.filename;
  a.click();
  URL.revokeObjectURL(url);
  showToast('File downloaded successfully!');
}

// Modal
function setupModal() {
  const modal = document.getElementById('tag-modal');
  const closeBtn = document.getElementById('close-modal');
  const cancelBtn = document.getElementById('cancel-tags-btn');
  const applyBtn = document.getElementById('apply-tags-btn');

  closeBtn.addEventListener('click', closeTagModal);
  cancelBtn.addEventListener('click', closeTagModal);
  applyBtn.addEventListener('click', applyTags);

  // Tag options
  const tagOptions = document.querySelectorAll('.tag-option');
  tagOptions.forEach(option => {
    option.addEventListener('click', () => {
      const tag = option.getAttribute('data-tag');
      toggleTag(tag);
      option.classList.toggle('selected');
    });
  });

  // Custom tag input
  document.getElementById('custom-tag-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const tag = e.target.value.trim();
      if (tag) {
        addTag(tag);
        e.target.value = '';
      }
    }
  });
}

function openTagModal() {
  if (!currentLookupResult) return;
  selectedTags = [...(currentLookupResult.tags || [])];
  updateSelectedTagsDisplay();
  document.getElementById('tag-modal').classList.add('show');
}

function closeTagModal() {
  document.getElementById('tag-modal').classList.remove('show');
  selectedTags = [];
  document.querySelectorAll('.tag-option').forEach(opt => opt.classList.remove('selected'));
}

function toggleTag(tag) {
  const index = selectedTags.indexOf(tag);
  if (index > -1) {
    selectedTags.splice(index, 1);
  } else {
    selectedTags.push(tag);
  }
  updateSelectedTagsDisplay();
}

function addTag(tag) {
  if (!selectedTags.includes(tag)) {
    selectedTags.push(tag);
    updateSelectedTagsDisplay();
  }
}

function removeTag(tag) {
  const index = selectedTags.indexOf(tag);
  if (index > -1) {
    selectedTags.splice(index, 1);
    updateSelectedTagsDisplay();
  }
}

function updateSelectedTagsDisplay() {
  const container = document.getElementById('selected-tags');
  container.innerHTML = selectedTags.map(tag => `
    <div class="tag-item">
      ${tag}
      <button class="tag-remove" onclick="removeTag('${tag}')">&times;</button>
    </div>
  `).join('');
}

function applyTags() {
  if (currentLookupResult) {
    currentLookupResult.tags = [...selectedTags];
    
    // Update in main threats array if exists
    const threat = threats.find(t => t.id === currentLookupResult.id);
    if (threat) {
      threat.tags = [...selectedTags];
    }
    
    showToast(`${selectedTags.length} tag(s) applied successfully!`);
    closeTagModal();
  }
}

// Toast notification
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
}